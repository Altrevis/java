package com.ynov.oop.ui.window;

public interface Updatable {
    void update();
}
